import { Component, Inject, TemplateRef } from '@angular/core';
import { ModalDirective, BsModalRef, BsModalService } from 'ngx-bootstrap/modal';

import {RedditService} from '../services/reddit.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  providers: [RedditService, BsModalRef, ModalDirective]
})
export class HomeComponent {
  public modalRef: BsModalRef; // {1}

  items: any;
  isLoading: any;

  constructor(private redditService:RedditService, private modalService: BsModalService) { }

  ngOnInit() {
    console.log('888999 1001 b - ngOnInit');
    this.getPosts('sports', 20);
  }

  openPopupSports(): void {
    //var infoModal = document.getElementById('infoModal');
    //infoModal.show();
  }
  public openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template); // {3}
  }  

  getPosts(category, limit) {
    this.isLoading = true;
    this.redditService.getPosts(category, limit).subscribe(response => {
      console.log('Getting sports news... 003');
      console.log(response);
      this.items = response.data.children;
      /**
       * 

      this.items.forEach(element => {
        if (this.actualWidth <= 400 ) {
          var str = element.data.title;
          str = str.substring(1, 100); 
          element.data.title = str;
        }
        console.log(element.data.title);
      });
       */
      this.isLoading = false;
    });
  }

  onRowClicked(item) {
    //alert("You select symbol: " + item.symbol);
    alert(item.data.title);
    //var infoModal = document.getElementById('infoModal');
    //infoModal.hide();
    //this.dialogRef.close(item);
    //this.infoModal.hide();
  }

}
